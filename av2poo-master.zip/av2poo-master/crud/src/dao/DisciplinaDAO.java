package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Model.Disciplina;
import jdbc.ConnectionFactory;


public class DisciplinaDAO {
	public void create(Disciplina disciplina)
	{
		Connection conexaoBD = null;
        PreparedStatement stmt = null;
        String sql = "INSERT INTO disciplina(nome) VALUES ('" + disciplina.getNome()+"')";
        
        try {
            conexaoBD = ConnectionFactory.getConnection();

            stmt = conexaoBD.prepareStatement(sql) ; //sql
            stmt.setString(1, disciplina.getNome());
            

            //executar query no banco
            stmt.executeUpdate();

            System.out.println("[DisciplinaDAO] Disciplina inserido no banco com sucesso!");
        
        } catch (SQLException e)
        {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally
        {
            System.out.println(" Fechando conexao!!");
            ConnectionFactory.closeConnection(conexaoBD, stmt);
        }
		

	}
	public void remover(Disciplina disciplina)
	{
		
		
		Connection conexaoBD = null;
        PreparedStatement stmt = null;
        String sql = "DELETE FROM disciplina where id=" + disciplina.getId()+"";
        
        try {
            conexaoBD = ConnectionFactory.getConnection();
            stmt = conexaoBD.prepareStatement(sql) ;          

            //executar query no banco
            stmt.executeUpdate();

            System.out.println("[DisciplinaDAO] Disciplina excluida no banco com sucesso!");
        
        } catch (SQLException e)
        {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally
        {
            System.out.println(" Fechando conexao!!");
            ConnectionFactory.closeConnection(conexaoBD, stmt);
        }

	}
	public void editar(Disciplina disciplina)
	{
		
		
		Connection conexaoBD = null;
        PreparedStatement stmt = null;
        String sql = "UPDATE disciplina SET nome='"+disciplina.getNome()+"' where id=" + disciplina.getId()+"";
        
        try {
            conexaoBD = ConnectionFactory.getConnection();
            stmt = conexaoBD.prepareStatement(sql) ;          

            //executar query no banco
            stmt.executeUpdate();

            System.out.println("[DisciplinaDAO] Disciplina editada no banco com sucesso!");
        
        } catch (SQLException e)
        {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally
        {
            System.out.println(" Fechando conexao!!");
            ConnectionFactory.closeConnection(conexaoBD, stmt);
        }

		

	}
	
	public List<Disciplina> listar() {
		
		Connection conexaoBD = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "SELECT * from disciplina";
        List<Disciplina> l = new ArrayList<Disciplina>();
        
        try {
            
            conexaoBD = ConnectionFactory.getConnection();
         
            stmt = conexaoBD.prepareStatement(sql);
            rs = stmt.executeQuery();

            while(rs.next())
            {
            	Disciplina disciplina = new Disciplina(rs.getString("nome"));
		    	disciplina.setId(rs.getInt("id"));

                l.add(disciplina);
            }
           
            


        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally{
            ConnectionFactory.closeConnection(conexaoBD, stmt);
        }

        return l;

    }
	
}


