package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import Model.Disciplina;
import Model.Professor;
import jdbc.ConnectionFactory;

public class ProfessorDAO {
	public void create(Professor professor)
	{
		
			int id = professor.getDisciplina().getId();
						
		    Connection conexaoBD = null;
		    PreparedStatement stmt = null;
		    
		    String sql = "INSERT INTO professor values('"+professor.getCpf()+"', "
					+ "'"+professor.getNome()+"', '"+professor.getEmail()+"', "+id+" )";

		    
		    try {
	            conexaoBD = ConnectionFactory.getConnection();

	            stmt = conexaoBD.prepareStatement(sql) ; //sql
	            stmt.setString(1, professor.getCpf());
	            stmt.setString(2, professor.getNome());
	            stmt.setString(3, professor.getEmail());
	            stmt.setInt(4, id);
	            

	            //executar query no banco
	            stmt.executeUpdate();

	            System.out.println("[ProfessorDAO] Professor inserido no banco com sucesso!");
	        
	        } catch (SQLException e)
	        {
	            e.printStackTrace();
	        }
	        catch (ClassNotFoundException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }finally
	        {
	            System.out.println(" Fechando conexao!!");
	            ConnectionFactory.closeConnection(conexaoBD, stmt);
	        }      
			
			
		
		

	}
	public void remover(Professor professor)
	{	
	
			Connection conexaoBD = null;
			PreparedStatement stmt = null;
			String sql = "DELETE FROM professor WHERE cpf = '"+professor.getCpf()+"';";
			try {
	            conexaoBD = ConnectionFactory.getConnection();
	            stmt = conexaoBD.prepareStatement(sql) ;          

	            //executar query no banco
	            stmt.executeUpdate();

	            System.out.println("[ProfessorDAO] Professor excluida no banco com sucesso!");
	        
	        } catch (SQLException e)
	        {
	            e.printStackTrace();
	        }
	        catch (ClassNotFoundException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }finally
	        {
	            System.out.println(" Fechando conexao!!");
	            ConnectionFactory.closeConnection(conexaoBD, stmt);
	        }
			
		
	}
	
	public void editar(Professor professor)
	{		
			
			Connection conexaoBD = null;
	        PreparedStatement stmt = null;
	        int id = professor.getDisciplina().getId();
			String sql = "UPDATE professor set nome='"+professor.getNome()+"', email='"+professor.getEmail()+"', disciplina='"+id+"' where cpf="+professor.getCpf();
	        
	        try {
	            conexaoBD = ConnectionFactory.getConnection();
	            stmt = conexaoBD.prepareStatement(sql) ;          

	            //executar query no banco
	            stmt.executeUpdate();

	            System.out.println("[ProfessorDAO] Professor editada no banco com sucesso!");
	        
	        } catch (SQLException e)
	        {
	            e.printStackTrace();
	        }
	        catch (ClassNotFoundException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }finally
	        {
	            System.out.println(" Fechando conexao!!");
	            ConnectionFactory.closeConnection(conexaoBD, stmt);
	        }

		

	}
	
	
	
	
	public Disciplina getDisciplina(int id) {

			Connection conexaoBD = null;
	        PreparedStatement stmt = null;
			String sql = "SELECT * from disciplina where id="+id;
			
			ResultSet rs = null;

			
			try {
	            conexaoBD = ConnectionFactory.getConnection();
	            stmt = conexaoBD.prepareStatement(sql) ; 
	            rs = stmt.executeQuery();
				rs.next();
	            
				Disciplina disciplina = new Disciplina(rs.getString("nome"));
				
				disciplina.setId(rs.getInt("id"));
	            //executar query no banco
	            stmt.executeUpdate();

	            return disciplina;
	        
	        } catch (SQLException e)
	        {
	            e.printStackTrace();
	        }
	        catch (ClassNotFoundException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }finally
	        {
	            System.out.println(" Fechando conexao!!");
	            ConnectionFactory.closeConnection(conexaoBD, stmt);
	        }

		return null;
	}

	public List<Professor> listar() {
		
		Connection conexaoBD = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
		String sql = "SELECT * from professor";
		List<Professor> l= new ArrayList<Professor>();

        try {
            
            conexaoBD = ConnectionFactory.getConnection();
         
            stmt = conexaoBD.prepareStatement(sql);
            rs = stmt.executeQuery();

            while(rs.next())
            {
            	Professor professor = new Professor(rs.getString("cpf"), rs.getString("nome"), getDisciplina(rs.getInt("disciplina")), rs.getString("email"));

                l.add(professor);
            }
           
            


        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally{
            ConnectionFactory.closeConnection(conexaoBD, stmt);
        }

        return l;		
	}
	
	
	}

