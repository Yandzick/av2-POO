package Controller;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Model.Disciplina;
import dao.DisciplinaDAO;


public class DisciplinaController {
	public void create(Disciplina disciplina)
	{
		try {

            DisciplinaDAO dao = new DisciplinaDAO();
            dao.create(disciplina);

            
        } catch (Exception e) {
            System.out.println(" Erro no controller");
        }
		

	}
	public void remover(Disciplina disciplina)
	{
		
		
		try {

            DisciplinaDAO dao = new DisciplinaDAO();
            dao.remover(disciplina);

            
        } catch (Exception e) {
            System.out.println(" Erro no controller");
        }
		

	}
	public void editar(Disciplina disciplina)
	{
		
		
		try {

            DisciplinaDAO dao = new DisciplinaDAO();
            dao.editar(disciplina);

            
        } catch (Exception e) {
            System.out.println(" Erro no controller");
        }
		

	}
	
	public List<Disciplina> listar() {
		
		 List<Disciplina> disciplina = new ArrayList<Disciplina>();
	        try{
	            DisciplinaDAO dao = new DisciplinaDAO();
	            disciplina = dao.listar();
	        }
	        catch(Exception e)
	        {
	            System.out.println(" Erro ao ler disciplina");
	        }

	        return disciplina;
	}
}


