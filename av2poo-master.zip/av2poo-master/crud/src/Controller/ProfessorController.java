package Controller;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Model.Professor;
import dao.ProfessorDAO;


public class ProfessorController {
	public void create(Professor professor)
	{
		try {

            ProfessorDAO dao = new ProfessorDAO();
            dao.create(professor);

            
        } catch (Exception e) {
            System.out.println(" Erro no controller");
        }
		

	}
	public void remover(Professor professor)
	{
		
		
		try {

            ProfessorDAO dao = new ProfessorDAO();
            dao.remover(professor);

            
        } catch (Exception e) {
            System.out.println(" Erro no controller");
        }
		

	}
	public void editar(Professor professor)
	{
		
		
		try {

            ProfessorDAO dao = new ProfessorDAO();
            dao.editar(professor);

            
        } catch (Exception e) {
            System.out.println(" Erro no controller");
        }
		

	}
	
	public List<Professor> listar() {
		
		 List<Professor> Professor = new ArrayList<Professor>();
	        try{
	            ProfessorDAO dao = new ProfessorDAO();
	            Professor = dao.listar();
	        }
	        catch(Exception e)
	        {
	            System.out.println(" Erro ao ler Professor");
	        }

	        return Professor;
	}
}


